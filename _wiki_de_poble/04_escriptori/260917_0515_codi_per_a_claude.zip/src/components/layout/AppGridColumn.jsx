import { ChevronDown, ChevronRight, PanelLeftClose, PanelRightOpen } from 'lucide-react';

/**
 * Capçalera única de columna.
 * Ordre visual (obert): [ esquerra / titol ] … [ accions ] [ replegar ]
 * Collapsed: [ expandir ] + accions (vertical).
 */
export default function AppGridColumn({
  titol,
  icona: Icona = null,
  accions = [],
  esquerra = null, // node opcional a l'esquerra (ex. botó "Tot", lupa)
  plegable = false,
  obert = true,
  onPlega = null,
  onReplega = null,
  variant = null,
  children,
}) {
  const esAcordio = variant === 'accordion';
  const Chevron = obert ? ChevronDown : ChevronRight;

  const actionButtons = accions.map((a) => {
    const cls =
      a.variant === 'text'
        ? 'app-grid-col-header__accio-text'
        : a.variant === 'primary'
          ? 'app-grid-col-header__accio'
          : 'app-grid-col-header__accio-icon';
    return (
      <button
        key={a.id}
        type="button"
        className={cls}
        onClick={() => a.onAcciona?.()}
        disabled={a.desactivat || (a.onAcciona == null && a.variant !== 'text')}
        aria-label={a.etiqueta}
        title={a.etiqueta}
        aria-pressed={a.pressed}
      >
        {a.icona ? <a.icona size={18} aria-hidden focusable="false" /> : null}
        {a.label ? <span>{a.label}</span> : null}
      </button>
    );
  });

  if (variant === 'collapsed') {
    const CollapsedIcon = Icona || PanelRightOpen;
    return (
      <div className="app-grid-col-header app-grid-col-header--collapsed">
        <button
          type="button"
          className="btn-icon btn-icon--transparent"
          onClick={onReplega}
          aria-label={`Expandir ${titol}`}
          title={`Expandir ${titol}`}
        >
          <CollapsedIcon size={20} aria-hidden focusable="false" />
        </button>
        {actionButtons}
      </div>
    );
  }

  return (
    <div className={`app-grid-col-header${esAcordio ? ' app-grid-col-header--accordion' : ''}`}>
      {esquerra}

      {plegable ? (
        <button
          type="button"
          className="app-grid-col-header__plec"
          onClick={onPlega}
          aria-expanded={obert}
          title={`Plegar o desplegar ${titol}`}
        >
          <Chevron size={20} aria-hidden focusable="false" />
          {Icona ? <Icona size={20} aria-hidden focusable="false" /> : null}
          {titol ? <span className="app-grid-col-header__titol">{titol}</span> : null}
        </button>
      ) : (
        <div className="app-grid-col-header__plec app-grid-col-header__plec--fix">
          {Icona ? <Icona size={20} aria-hidden focusable="false" /> : null}
          {titol ? <span className="app-grid-col-header__titol">{titol}</span> : null}
        </div>
      )}

      <div className="app-grid-col-header__accions">
        {actionButtons}
        {children}
        {onReplega ? (
          <button
            type="button"
            className="app-grid-col-header__accio-icon d-desktop-only"
            onClick={onReplega}
            aria-label={`Replegar ${titol}`}
            title={`Replegar ${titol}`}
          >
            <PanelLeftClose size={18} aria-hidden focusable="false" />
          </button>
        ) : null}
      </div>
    </div>
  );
}
